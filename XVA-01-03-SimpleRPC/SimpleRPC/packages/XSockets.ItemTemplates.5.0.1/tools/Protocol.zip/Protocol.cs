using System.Collections.Generic;
using System.Linq;
using System.Text;
using XSockets.Core.Common.Protocol;
using XSockets.Core.Common.Socket.Event.Arguments;
using XSockets.Core.Common.Socket.Event.Interface;
using XSockets.Core.Common.Utility.Serialization;
using XSockets.Plugin.Framework;
using XSockets.Plugin.Framework.Attributes;
using XSockets.Protocol;

namespace $rootnamespace$
{
    /*
    TODO: Implement your logic for frames going in/out as well as the framereading if needed.
          See all virtual methods to override if needed.
    */
    [Export(typeof(IXSocketProtocol), Rewritable = Rewritable.No)]
    public class $safeitemrootname$ : XSocketProtocol
    {
        /*
        public override bool Match(IList<byte> handshake)
        {
            //Return true if the handshake matches your protocol
        }
        */

        public override bool CanDoHeartbeat()
        {
            return false;
        }

        public override string HostResponse
        {
            get { return "$safeitemrootname$"; }
        }

        public override IXSocketProtocol NewInstance()
        {
            return new $safeitemrootname$();
        }
    }
}
