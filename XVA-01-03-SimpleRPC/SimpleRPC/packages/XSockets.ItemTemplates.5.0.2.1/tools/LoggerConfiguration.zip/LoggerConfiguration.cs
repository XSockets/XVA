using System.IO;
using Serilog;
using XSockets.Logger;

namespace $rootnamespace$
{
    // For details about configuration, visit http://serilog.net
    public class $safeitemrootname$: XLogger
    {    
        public $safeitemrootname$()
        {
            Log.Logger = new LoggerConfiguration().MinimumLevel.Information()
            .WriteTo.ColoredConsole()
            .WriteTo.RollingFile(Path.Combine(System.IO.Directory.GetCurrentDirectory(), "Log\\Log-{Date}.txt"))
            .WriteTo.Trace()
            .CreateLogger();
        }
    }
}
