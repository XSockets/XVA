using XSockets.Core.XSocket;
using XSockets.Core.XSocket.Helpers;
using XSockets.Plugin.Framework;
using XSockets.Plugin.Framework.Attributes;

namespace $rootnamespace$
{
    /// <summary>
    /// There will only be one instance of this class
    /// A singleton...
    /// </summary>
    [XSocketMetadata("$safeitemrootname$", PluginRange.Internal)]
    public class $safeitemrootname$ : XSocketController
    {
        
    }
}
