using System.Threading.Tasks;
using XSockets.Core.XSocket;

namespace $rootnamespace$
{
    public class $safeitemrootname$ : PersistentObjectStorage
    {
        public override Task Clear<T>(T controller)
        {
            return base.Clear<T>(controller);
        }

        public override Task<object> Get<T>(T controller, string key)
        {
            return base.Get<T>(controller, key);
        }

        public override Task Remove<T>(T controller, string key)
        {
            return base.Remove<T>(controller, key);
        }

        public override Task Set<T>(T controller, string key, object value)
        {
            return base.Set<T>(controller, key, value);
        }
    }
}
