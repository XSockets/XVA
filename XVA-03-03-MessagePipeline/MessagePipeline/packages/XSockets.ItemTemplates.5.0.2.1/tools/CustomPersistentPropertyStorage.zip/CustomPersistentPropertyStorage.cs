using System;
using System.Threading.Tasks;
using XSockets.Core.XSocket;

namespace $rootnamespace$
{    
    public class $safeitemrootname$ : PersistentPropertyStorage
    {
        public override async Task ReadFromPropertyStorage<T>(T controller)
        {
            throw new NotImplementedException("Implement custom storage for property values");
        }

        public override async Task WriteToPropertyStorage<T>(T controller)
        {
            throw new NotImplementedException("Implement custom storage for property values");
        }
    }
}
