using System.Threading.Tasks;
using XSockets.Core.Common.Socket;
using XSockets.Core.Common.Socket.Attributes;
using XSockets.Core.XSocket;

namespace $rootnamespace$
{
    public class $safeitemrootname$ : AuthorizationModule
    {
    	public override Task<bool> IsAuthorized(IXSocketController controller, IAuthorizeAttribute authorizeAttribute)
        {
            return base.IsAuthorized(controller, authorizeAttribute);
        }
    }
}
