using System.Threading.Tasks;
using XSockets.Core.Common.Socket;
using XSockets.Core.Common.Socket.Event.Interface;
using XSockets.Core.XSocket;

namespace $rootnamespace$
{
    public class $safeitemrootname$ : XSocketPipeline
    {
        public override async Task OnIncomingMessage(IXSocketController controller, IMessage e)
        {
            await base.OnIncomingMessage(controller, e);
        }

        public override async Task<IMessage> OnOutgoingMessage(IXSocketController controller, IMessage e)
        {
            return await base.OnOutgoingMessage(controller, e);
        }
    }
}
