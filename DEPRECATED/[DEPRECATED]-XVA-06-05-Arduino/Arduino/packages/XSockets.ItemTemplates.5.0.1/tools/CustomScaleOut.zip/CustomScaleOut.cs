using System;
using System.Threading.Tasks;
using XSockets.Core.Common.Enterprise;
using XSockets.Core.Common.Protocol;
using XSockets.Core.Common.Socket.Event.Interface;
using XSockets.Enterprise.Scaling;

namespace $rootnamespace$
{
    public class $safeitemrootname$ : BaseScaleOut
    {
        /// <summary>
        /// Called at startup, setup/prepare your scaleout
        /// </summary>
        public override void Init()
        {
            throw new NotImplementedException();
        }
        
        /// <summary>
        /// Publish the message to the scaleout so that other servers can receive it
        /// </summary>
        /// <param name="message"></param>
        public override Task Publish(MessageDirection direction, IMessage message, ScaleOutOrigin scaleOutOrigin)
        {
            throw new NotImplementedException();
        }

        /// <summary>
        /// Subscribe for messages published from other servers by using AzureServiceBus or similar techniques
        /// 
        /// You can ofcourse do polling to a data source, but performance will be suffering from that.
        /// </summary>
        public override Task Subscribe()
        {
            throw new NotImplementedException();
        }
    }
}

